# LightNovelWorld
Инструкций за пускане:
Преди пускане,да се напише в Packeg Manager Console и да се напише командата update-database
